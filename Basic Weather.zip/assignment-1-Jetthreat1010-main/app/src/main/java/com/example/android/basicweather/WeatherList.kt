package com.example.android.basicweather

data class Weather(val date:String, val high:String, val low:String, val precip:String, val descShort:String, var descLong:String)
